import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatDialogModule } from '@angular/material/dialog';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LayoutOneModule } from './layout/layout-one/layout-one.module';
import { LayoutTwoModule } from './layout/layout-two/layout-two.module';
import { LoaderModule } from './loader/loader.module';

import { ToastModule } from './component/_shared/toast/toast.module';

import { LoaderInterceptorService } from './service/interceptor/loader.interceptor.service';
import { InterceptorService } from './service/interceptor/interceptor.service';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,

        MatDialogModule,

        HttpClientModule,

        LayoutOneModule,
        LayoutTwoModule,
        LoaderModule,

        ToastModule
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: LoaderInterceptorService,
            multi: true
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: InterceptorService,
            multi: true
        }
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }