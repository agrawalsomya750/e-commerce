import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SignInModule } from '../component/sign-in/sign-in.module';

import { HeaderComponent } from './header.component';

@NgModule({
    declarations: [
        HeaderComponent
    ],
    imports: [
        CommonModule,

        SignInModule
    ],
    exports: [
        HeaderComponent
    ]
})
export class HeaderModule { }