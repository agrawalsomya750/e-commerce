import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { MatDialog } from '@angular/material/dialog';

import { UserController } from '@ECommerce/controller/user.controller';

import { CartService } from '@ECommerce/service/cart.service';
import { AuthenticationService } from '@ECommerce/service/authentication.service';

import { SignInComponent } from '@ECommerce/component/sign-in/sign-in.component';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

    cartCount: number = 0;
    user: any;

    constructor(
        private dialog: MatDialog,
        private router: Router,
        private userController: UserController,
        private cartService: CartService,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit(): void {
        this.cartService.cartCount$.subscribe(count => {
            this.cartCount = count;
        });

        this.authenticationService.triggerSignIn$.subscribe(() => {
            this.getUser();
        });

        if (this.authenticationService.isSignIn()) {
            this.getUser();
        }
    }

    public openSignInForm() {
        const dialogRef = this.dialog.open(SignInComponent, {
            width: '650px',
            panelClass: 'mat_dialog_container_override',
        });
    }

    public navigateToCartPage() {
        this.router.navigate(['/shopping-cart']);
    }

    private getUser() {
        this.userController.getUser()
            .subscribe((res: any) => {
                this.user = res;
            }, error => {
                console.error('error in getUser - ', error);
            });
    }

    public logout() {
        this.authenticationService.logout();
    }

}