import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';

import { Observable } from "rxjs";

import { environment } from "src/environments/environment";

import { UserI } from "@ECommerce/model/user.model";

@Injectable({
    providedIn: 'root'
})

export class UserController {
    constructor(
        private http: HttpClient
    ) { }

    createUser(userObj: any) {
        return this.http.post(`${environment.API_URL}users`, userObj);
    }

    validateUser(email: any) {
        return this.http.post(`${environment.API_URL}users/is-available`, email);
    }

    getUser(): Observable<UserI> {
        return this.http.get<UserI>(`${environment.API_URL}auth/profile`);
    }

}