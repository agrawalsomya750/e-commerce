import { Injectable } from "@angular/core";

import {
    HttpClient,
    HttpParams,
    HttpHeaders,
} from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from "src/environments/environment";

import { ProductI } from "@ECommerce/model/product.model";

@Injectable({
    providedIn: 'root'
})

export class ProductController {
    constructor(
        private http: HttpClient
    ) { }

    getProducts(paramsObj: any): Observable<ProductI[]> {
        let params = new HttpParams();

        if (paramsObj['title']) {
            params = params.append('title', paramsObj['title']);
        }
        if (paramsObj['categoryId']) {
            params = params.append('categoryId', paramsObj['categoryId'].toString());
        }
        if (paramsObj['priceMin'] != undefined) {
            params = params.append('price_min', paramsObj['priceMin'].toString());
        }
        if (paramsObj['priceMax'] != undefined) {
            params = params.append('price_max', paramsObj['priceMax'].toString());
        }
        if (paramsObj['offset'] != undefined) {
            params = params.append('offset', paramsObj['offset'].toString());
        }
        if (paramsObj['limit'] != undefined) {
            params = params.append('limit', paramsObj['limit'].toString());
        }

        return this.http.get<ProductI[]>(`${environment.API_URL}products`, { params: params });
    }

    getProductByID(id: number): Observable<ProductI> {
        return this.http.get<ProductI>(`${environment.API_URL}products/${id}`);
    }

}