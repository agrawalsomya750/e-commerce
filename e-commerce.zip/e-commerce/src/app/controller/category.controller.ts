import { Injectable } from "@angular/core";

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from "src/environments/environment";

import { CategoryI } from "@ECommerce/model/category.model";

@Injectable({
    providedIn: 'root'
})

export class CategoryController {
    constructor(
        private http: HttpClient
    ) { }

    getCategories(): Observable<CategoryI[]> {
        return this.http.get<CategoryI[]>(`${environment.API_URL}categories`);
    }

}