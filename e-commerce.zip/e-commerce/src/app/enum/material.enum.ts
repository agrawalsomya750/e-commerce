export enum MaterialFormFieldAppearance {
    FORM_FIELD_APPEARANCE_NONE = 'none',
    FORM_FIELD_APPEARANCE_STANDARD = 'standard',
    FORM_FIELD_APPEARANCE = 'outline',
    FORM_FIELD_APPEARANCE_FILL = 'fill'
}