export enum FormErrorEnum {
    REQUIRED = 'Required field',
    EMAIL = 'Invalid email',
    INVALID_PATTERN = 'Invalid pattern',
    PATTERN = '{value}',
    MINIMUM_LENGTH = 'Minimum length: {value}',
    MAXIMUM_LENGTH = 'Maximum length: {value}'
}