import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

import { FormErrorEnum } from '@ECommerce/enum/form.enum';
import { MaterialFormFieldAppearance } from '@ECommerce/enum/material.enum';

import { SignInController } from '@ECommerce/controller/sign-in.controller';

import { StorageService } from '@ECommerce/service/storage.service';
import { AuthenticationService } from '@ECommerce/service/authentication.service';
import { ToastService } from '@ECommerce/service/toast.service';

@Component({
    selector: 'app-sign-in',
    templateUrl: './sign-in.component.html',
    styleUrls: []
})

export class SignInComponent implements OnInit {

    FormErrorEnum = FormErrorEnum;
    MaterialFormFieldAppearance = MaterialFormFieldAppearance;

    // Form group for sign-in form, initialized in signInInit()
    // The `!` (non-null assertion) tells TypeScript that this property will be initialized before use.
    signInFG!: FormGroup;

    hide = true;

    constructor(
        private dialogRef: MatDialogRef<SignInComponent>,
        private signInFB: FormBuilder,
        private signInController: SignInController,
        private storageService: StorageService,
        private authenticationService: AuthenticationService,
        private toastService: ToastService
    ) {
        this.dialogRef.disableClose = true;
    }

    ngOnInit(): void {
        this.signInInit();
    }

    private signInInit() {
        this.signInFG = this.signInFB.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required]]
        });
    }

    public signIn() {
        if (this.signInFG.invalid) {
            console.log('invalid form - ', this.signInFG);
            return;
        }

        this.signInController.signIn(this.signInFG.value).subscribe((loginRes: any) => {
            if (loginRes.access_token && loginRes.refresh_token) {
                this.toastService.showToast(`User signed in successfully!`, 'success');
                this.storageService.setStorage('access_token', loginRes.access_token);
                this.storageService.setStorage('refresh_token', loginRes.refresh_token);
                this.authenticationService.triggerSignInFunction();
                this.dialogRef.close(true);
            }
        }, error => {
            console.log('error in signIn() - ', error);
        });
    }

    public closeSignInFrom() {
        this.signInFG.reset();
        this.dialogRef.close();
    }

    public errorHandling = (control: string, error: string) => {
        return this.signInFG.controls[control].hasError(error);
    }

}