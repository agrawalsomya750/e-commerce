import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CartI } from '@ECommerce/model/cart.model';

import { CartService } from '@ECommerce/service/cart.service';

@Component({
    selector: 'app-shopping-cart',
    templateUrl: './shopping-cart.component.html',
    styleUrls: ['./shopping-cart.component.scss']
})

export class ShoppingCartComponent implements OnInit {

    cartItems: CartI[] = [];

    constructor(
        private router: Router,
        private cartService: CartService
    ) { }

    ngOnInit(): void {
        this.getCartItems();
    }

    private getCartItems() {
        this.cartItems = this.cartService.getCartItems();
    }

    public decreaseCartItems(item: CartI) {
        this.cartService.decreaseCartItems(item.id);
        this.getCartItems(); // Refresh the cart after removing or decreasing item
    }

    public increaseCartItems(item: CartI) {
        this.cartService.increaseCartItems(item.id);
        this.getCartItems(); // Refresh the cart after increasing item quantity
    }

    public calculateTotalAmount(): number {
        return this.cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
    }

    public navigateToProductPage() {
        this.router.navigate(['/product/list']);
    }

}