import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatRippleModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

import { FlexLayoutModule } from '@angular/flex-layout';

import { ShoppingCartRoutingModule } from './shopping-cart-routing.module';
import { ShoppingCartComponent } from './shopping-cart.component';

@NgModule({
    declarations: [
        ShoppingCartComponent
    ],
    imports: [
        CommonModule,
        ShoppingCartRoutingModule,

        MatRippleModule,
        MatButtonModule,
        MatCardModule,
        MatButtonToggleModule,

        FlexLayoutModule
    ]
})
export class ShoppingCartModule { }
