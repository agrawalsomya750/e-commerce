import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { FormControl } from '@angular/forms';

@Component({
    selector: 'app-search-bar',
    templateUrl: './search-bar.component.html',
    styleUrls: ['./search-bar.component.scss']
})

export class SearchBarComponent implements OnInit {

    searchFC: FormControl = new FormControl('');

    @Input()
    type: string = 'text';

    @Input()
    searchBy: string = '';

    @Input()
    clear: boolean = false;

    @Input()
    emitValueOnChange: boolean = false;

    @Output()
    emitSearch = new EventEmitter<String>();

    active: boolean = false;

    ngOnInit(): void {

        if (this.emitValueOnChange) {
            this.searchFC.valueChanges.subscribe((value) => {
                if (value.length == 0) {
                    this.emitSearch.emit('');
                } else {
                    this.emitSearch.emit(value);
                }
            })
        }

    }

    ngOnChanges() {
        if (!this.clear) {
            this.searchFC.reset('', { onlySelf: true, emitEvent: false });
        }

    }

    public searchFn() {
        if (this.searchFC.value.length > 0) {
            this.active = true;
            this.emitSearch.emit(this.searchFC.value);
            return;
        }

        if (!this.active) {
            return;
        }

        if (this.searchFC.value.length == 0 && this.active) {
            this.active = false;
            this.emitSearch.emit('');
            return;
        }
    }

    public searchReset() {
        this.searchFC.reset('');
        this.searchFn();
    }

    public searchClear() {
        this.active = false;
        this.searchFC.reset('');
    }

}