import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductViewRoutingModule } from './view-routing.module';
import { ProductViewComponent } from './view.component';

@NgModule({
    declarations: [
        ProductViewComponent
    ],
    imports: [
        CommonModule,
        ProductViewRoutingModule
    ]
})
export class ProductViewModule { }
