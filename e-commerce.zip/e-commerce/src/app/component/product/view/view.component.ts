import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Product, ProductI } from '@ECommerce/model/product.model';

import { ProductController } from '@ECommerce/controller/product.controller';

import { CartService } from '@ECommerce/service/cart.service';

@Component({
    selector: 'app-view',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss']
})
export class ProductViewComponent implements OnInit {

    productID: any;

    productI = new Product();

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private productController: ProductController,
        private cartService: CartService
    ) { }

    ngOnInit(): void {
        this.activatedRoute.params.subscribe(params => {
            this.productID = params['id'];
        })

        this.getProductByID();
    }

    private getProductByID() {
        this.productController.getProductByID(this.productID)
            .subscribe((productRes: ProductI) => {
                this.productI = productRes;
            },
                error => {
                    console.error('error in getProductByID - ', error);
                });
    }

    public addToCart(productI: ProductI) {
        this.cartService.addToCart({
            id: productI.id,
            title: productI.title,
            description: productI.description,
            price: productI.price,
            image: productI.images?.[0] || '',
            quantity: 1
        });
    }

    public toggleZoom(event: MouseEvent) {
        const img = event.target as HTMLImageElement;
        if (img.classList.contains('zoomed')) {
            img.classList.remove('zoomed');
        } else {
            img.classList.add('zoomed');
        }
    }

    public buyNow(productI: ProductI) {
        this.addToCart(productI);
        this.router.navigate(['/shopping-cart']);
    }

}