import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { MatPaginator } from '@angular/material/paginator';

import {
    merge,
    fromEvent,
    of as observableOf
} from 'rxjs';

import {
    map,
    startWith,
    switchMap,
    catchError,
} from "rxjs/operators";

import { Category, CategoryI } from '@ECommerce/model/category.model';
import { Product, ProductI } from '@ECommerce/model/product.model';

import { CategoryController } from '@ECommerce/controller/category.controller';
import { ProductController } from '@ECommerce/controller/product.controller';

@Component({
    selector: 'app-list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.scss']
})
export class ProductListComponent implements OnInit {

    searchValue: string = '';

    selectedCategoryID: number = 0;

    priceMin: number = 0;
    priceMax: number = 100;

    offset: number = 0;
    limit: number = 10;

    resultLength: number = 0;
    defaultPageSize = 10;
    pageSizeOption = [10, 20, 30, 40, 50];

    categoryListI = [new Category()];
    productListI = [new Product()];

    currentImageIndex: number[] = [];

    // The '!' (non-null assertion operator) tells TypeScript that the paginator will always be assigned a value 
    // after the component's view initializes, preventing TypeScript from throwing an error about potential null/undefined values.
    @ViewChild('paginator') paginator!: MatPaginator;
    @ViewChild('refreshBtn') refreshBtn!: ElementRef;

    constructor(
        private router: Router,
        private categoryController: CategoryController,
        private productController: ProductController
    ) { }

    ngOnInit(): void {
        this.getCategories();
    }

    private getCategories() {
        this.categoryController.getCategories().subscribe((categoryRes: CategoryI[]) => {
            this.categoryListI = categoryRes;
        },
            error => {
                console.error('error in getCategories - ', error);
            });
    }

    public formatLabel(value: number) {
        return value >= 1000 ? Math.round(value / 1000) + 'k' : value;
    }

    public searchFn($event: any) {
        this.searchValue = $event;
        this.refreshBtn.nativeElement.click();
    }

    public categoryFilter(category: CategoryI) {
        this.selectedCategoryID = category.id;
        this.refreshBtn.nativeElement.click();

    }

    public priceRangeChanged() {
        this.refreshBtn.nativeElement.click();
    }

    ngAfterViewInit() {
        // Merge events from paginator (page change) and refresh button click
        merge(
            this.paginator.page, // Emits when the paginator page changes
            fromEvent(this.refreshBtn.nativeElement, 'click') // Emits when the refresh button is clicked
        ).pipe(
            startWith({}),
            switchMap((): any => {
                const params: any = {
                    offset: this.paginator.pageIndex * this.paginator.pageSize || 0,
                    limit: this.paginator.pageSize || this.defaultPageSize,
                };

                if (this.searchValue) {
                    params.title = this.searchValue;
                }

                if (this.selectedCategoryID) {
                    params.categoryId = this.selectedCategoryID;
                }

                if (this.priceMin != null && this.priceMax != null) {

                    params.priceMin = this.priceMin;
                    params.priceMax = this.priceMax;
                }

                return this.productController.getProducts(params).pipe(catchError(() => observableOf(null)));
            }),
            map((productRes): any => {
                if (productRes == null) {
                    this.resultLength = 0;
                    return [];
                }
                this.resultLength = 500; // TODO: Update dynamically from API response if available
                return productRes;
            })
        ).subscribe((productRes) => {
            this.productListI = productRes;
        });
    }

    public prevImage(index: number, event: Event) {
        event.stopPropagation(); // Prevents click from propagating to the parent div
        if (this.currentImageIndex[index] > 0) {
            this.currentImageIndex[index]--;
        }
    }

    public nextImage(index: number, event: Event) {
        event.stopPropagation(); // Prevents click from propagating to the parent div
        if (this.currentImageIndex[index] < this.productListI[index].images.length - 1) {
            this.currentImageIndex[index]++;
        }
    }

    public navigateToProductViewPage(product: ProductI) {
        this.router.navigate(['/product/view', product.id]);
    }

}