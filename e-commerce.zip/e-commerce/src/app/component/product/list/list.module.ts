import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

import { FlexLayoutModule } from '@angular/flex-layout';

import { MatCardModule } from '@angular/material/card';
import { MatRippleModule } from '@angular/material/core';
import { MatSliderModule } from '@angular/material/slider';
import { MatPaginatorModule } from '@angular/material/paginator';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { SearchBarModule } from '@ECommerce/component/_shared/search-bar/search-bar.module';

import { ProductListRoutingModule } from './list-routing.module';
import { ProductListComponent } from './list.component';

@NgModule({
    declarations: [
        ProductListComponent
    ],
    imports: [
        CommonModule,
        ProductListRoutingModule,

        FormsModule,

        FlexLayoutModule,

        MatCardModule,
        MatRippleModule,
        MatSliderModule,
        MatPaginatorModule,

        NgbModule,

        SearchBarModule
    ]
})
export class ProductListModule { }