import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { VALIDATION_CONSTANT } from '@ECommerce/constant/validation.constant';

import { FormErrorEnum } from '@ECommerce/enum/form.enum';
import { MaterialFormFieldAppearance } from '@ECommerce/enum/material.enum';

import { UserController } from '@ECommerce/controller/user.controller';
import { ToastService } from '@ECommerce/service/toast.service';

@Component({
    selector: 'app-sign-up',
    templateUrl: './sign-up.component.html',
    styleUrls: ['./sign-up.component.scss']
})

export class SignUpComponent implements OnInit {

    VALIDATION_CONSTANT = VALIDATION_CONSTANT;

    FormErrorEnum = FormErrorEnum;
    MaterialFormFieldAppearance = MaterialFormFieldAppearance;

    // Form group for sign-in form, initialized in signInInit()
    // The `!` (non-null assertion) tells TypeScript that this property will be initialized before use.
    signUpFG!: FormGroup;

    hide: boolean = true;
    passwordPattern = ("^(?!.* )(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{0,}$");

    passwordRequirement = [
        { name: '8 characters' },
        { name: '1 uppercase' },
        { name: '1 lowercase' },
        { name: '1 number' },
        { name: 'No space' }
    ];

    constructor(
        private router: Router,
        private formBuilder: FormBuilder,
        private userController: UserController,
        private toastService: ToastService
    ) { }

    ngOnInit(): void {
        this.signUpFGInit();
    }

    private signUpFGInit() {
        this.signUpFG = this.formBuilder.group({
            name: ['', [Validators.required]],
            email: [, [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.pattern(this.passwordPattern), Validators.minLength(8)]],
            avatar: ['https://picsum.photos/800'] // INFO: Hardcoded, due to time constraint
        });
    }

    public signUpSubmit() {
        if (this.signUpFG.invalid || !this.isPasswordValid()) {
            this.signUpFG.get('password')?.setErrors({ passwordInvalid: true });
            console.log('invalid form - ', this.signUpFG);
            return;
        }

        this.validateUser();
    }

    private validateUser() {
        const emailControl = this.signUpFG.get('email');

        if (!emailControl) {
            console.error('Email control not found in the form.');
            return;
        }

        const emailObj = {
            email: emailControl.value
        };

        this.userController.validateUser(emailObj)
            .subscribe((validateRes: any) => {
                if (validateRes.isAvailable) {
                    this.toastService.showToast(`Email already exists`, 'danger');
                    emailControl.setErrors({ emailAlreadyExists: true }); // No more TS error
                } else {
                    this.signUp();
                }
            },
                error => {
                    console.error('error in validateUser - ', error);
                });
    }

    private signUp() {
        this.userController.createUser(this.signUpFG.value)
            .subscribe((createRes: any) => {
                if (createRes.id) {
                    this.router.navigate(['/product/list']);
                }
            },
                error => {

                    console.error('error in createUser - ', error);
                });
    }

    public validatePasswordRequirement(policy: any): boolean {
        const password = this.signUpFG.get('password')?.value || ''; // Ensures `password` is always a string

        if (policy.name == '1 uppercase') {
            return /[A-Z]/.test(password);
        } else if (policy.name == '1 lowercase') {
            return /[a-z]/.test(password);
        } else if (policy.name == '1 number') {
            return /\d/.test(password);
        } else if (policy.name == '8 characters') {
            return password.length >= 8;
        } else if (policy.name == 'No space') {
            return !/\s/.test(password);
        }

        return false;
    }

    private isPasswordValid(): boolean {
        const password = this.signUpFG.get('password')?.value;
        if (!password) return false;

        return (
            password.length >= 8 &&
            /[A-Z]/.test(password) &&
            /[a-z]/.test(password) &&
            /\d/.test(password) &&
            !/\s/.test(password)
        );
    }

    public errorHandling = (control: string, error: string) => {
        return this.signUpFG.controls[control].hasError(error);
    }

}