import { Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { LoaderService } from '@ECommerce/service/loader.service';

@Component({
    selector: 'app-loader',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss'],
})

export class LoaderComponent {
    isLoading: BehaviorSubject<boolean> = this.loaderOneService.isLoading;

    constructor(
        public loaderOneService: LoaderService
    ) { }
}

