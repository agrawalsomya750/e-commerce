import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { CartI } from '@ECommerce/model/cart.model';

import { StorageService } from './storage.service';
import { ToastService } from './toast.service';

@Injectable({
    providedIn: 'root'
})

export class CartService {

    private cartItems: CartI[] = [];
    private cartCount = new BehaviorSubject<number>(0); // Observable for cart count
    cartCount$ = this.cartCount.asObservable();

    constructor(
        private storageService: StorageService,
        private toastService: ToastService
    ) {
        this.loadCartFromLocalStorage();
    }

    private saveCartToLocalStorage() {
        this.storageService.setStorage('cartItems', JSON.stringify(this.cartItems));
    }

    private loadCartFromLocalStorage() {
        const storedCart = this.storageService.getStorage('cartItems');
        if (storedCart) {
            this.cartItems = JSON.parse(storedCart);
            this.updateCartCount();
        }
    }

    public addToCart(product: CartI) {
        const existingItem = this.cartItems.find(item => item.id == product.id);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cartItems.push({ ...product, quantity: 1 });
        }

        this.saveCartToLocalStorage();
        this.updateCartCount();

        this.toastService.showToast(`Item added successfully!`, 'success');
    }

    public getCartItems(): CartI[] {
        return this.cartItems;
    }

    public increaseCartItems(itemId: number) {
        const item = this.cartItems.find(i => i.id == itemId);
        if (item) {
            item.quantity++;
            this.saveCartToLocalStorage();
            this.updateCartCount();
        }
    }

    public decreaseCartItems(itemId: number) {
        const itemIndex = this.cartItems.findIndex(i => i.id == itemId);
        if (itemIndex != -1) {
            if (this.cartItems[itemIndex].quantity > 1) {
                this.cartItems[itemIndex].quantity--;
            } else {
                this.cartItems.splice(itemIndex, 1); // Remove item if quantity is 0
            }
            this.saveCartToLocalStorage();
            this.updateCartCount();
        }
    }

    private updateCartCount() {
        const totalItems = this.cartItems.reduce((acc, item) => acc + item.quantity, 0);
        this.cartCount.next(totalItems);
    }
}