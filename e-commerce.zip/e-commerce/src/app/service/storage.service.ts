import { Injectable } from '@angular/core';

import * as CryptoJS from 'crypto-js';

@Injectable({
    providedIn: 'root'
})
export class StorageService {
    private xgr6fh: string = 'a65zsxs#%$%%vdbtwqe805rfgt785yhuj_@ikol10p)*fgbfb';

    constructor() { }

    deleteStorage(key: string): void {
        localStorage.removeItem(key);
    }

    setStorage(key: string, value: string): void {
        // localStorage.setItem(key, value);
        return this.setStorageWithEncryption(key, value);
    }

    getStorage(key: string): string | null {
        // return localStorage.getItem(key);
        return this.getStorageWithEncryption(key);
    }

    clearStorage(): void {
        localStorage.clear();
        sessionStorage.clear();
    }

    private setStorageWithEncryption(key: any, value: any) {
        const encryptedKey = key;
        // const encryptedKey = this.encryptData(key);
        const encryptedValue = this.encryptData(value);

        return localStorage.setItem(encryptedKey, encryptedValue);
    }

    private getStorageWithEncryption(key: any) {
        const encryptedKey = key;
        // const encryptedKey = this.encryptData(key);
        const encryptedValue = localStorage.getItem(encryptedKey);

        if (encryptedValue) {
            return this.decryptData(encryptedValue);
        } else {
            return null;
        }
    }

    private encryptData(data: string): string {
        const valueInString = JSON.stringify(data);
        return CryptoJS.AES.encrypt(valueInString, this.xgr6fh as string).toString();
    }

    private decryptData(data: string): string {

        const bytes = CryptoJS.AES.decrypt(data, this.xgr6fh as string);
        const decryptedValue = bytes.toString(CryptoJS.enc.Utf8);

        try {
            return JSON.parse(decryptedValue);
        } catch (e) {
            return decryptedValue;
        }
    }
}