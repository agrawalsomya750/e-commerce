import { Injectable } from "@angular/core";
import { Router } from "@angular/router";

import { Subject } from 'rxjs';

import { StorageService } from "./storage.service";

@Injectable({
    providedIn: 'root'
})

export class AuthenticationService {

    private triggerSignInSubject = new Subject<void>();
    triggerSignIn$ = this.triggerSignInSubject.asObservable();

    constructor(
        private router: Router,
        private storageService: StorageService,
    ) { }

    public isSignIn() {
        let access_token = this.storageService.getStorage('access_token');

        if (
            access_token == 'undefined' ||
            access_token == 'null' ||
            access_token == null ||
            access_token == ''
        ) {
            return false;
        } else {
            return true;
        }
    }

    public logout() {
        this.storageService.deleteStorage('access_token');
        this.storageService.deleteStorage('refresh_token');
        this.router.navigate(['/']).then(() => {
            window.location.reload();
        });
    }

    public triggerSignInFunction() {
        this.triggerSignInSubject.next();
    }

}