import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class ToastService {
    private toastMessage = new BehaviorSubject<{ message: string; type: 'success' | 'danger' } | null>(null);
    toastMessage$ = this.toastMessage.asObservable();

    public showToast(message: string, type: 'success' | 'danger') {
        this.toastMessage.next({ message, type });

        // Auto-hide after 3 seconds
        setTimeout(() => {
            this.toastMessage.next(null);
        }, 3000);
    }

}