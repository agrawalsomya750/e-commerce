import { Injectable } from '@angular/core';

import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { LoaderService } from '@ECommerce/service/loader.service'; 

@Injectable()

export class LoaderInterceptorService implements HttpInterceptor {
    httpCount: number = 0;

    constructor(
        private loaderOneService: LoaderService
    ) { }

    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
        let skipLoader = request.headers.get('skipLoader');

        if (skipLoader == 'YES') {
            // console.log('skipLoader');
        } else {
            this.httpCount++;
            this.loaderOneService.show();

            return next.handle(request).pipe(
                finalize(() => {
                    this.httpCount--;
                    if (this.httpCount == 0) {
                        this.loaderOneService.hide();
                        // console.log('return next');
                    }
                }),
            )
        }
        return next.handle(request).pipe(
            finalize(() => {
                // console.log('return skipLoader');
            })
        )
    }
}
