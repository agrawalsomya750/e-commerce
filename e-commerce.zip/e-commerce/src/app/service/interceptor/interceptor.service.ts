import { Injectable } from '@angular/core';

import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse,
    HttpResponse
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { StorageService } from '@ECommerce/service/storage.service';
import { AuthenticationService } from '@ECommerce/service/authentication.service';
import { ToastService } from '@ECommerce/service/toast.service';

@Injectable({
    providedIn: 'root'
})

export class InterceptorService implements HttpInterceptor {

    constructor(
        private storageService: StorageService,
        private authenticationService: AuthenticationService,
        private toastService: ToastService
    ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (this.authenticationService.isSignIn()) {
            let accessToken = this.storageService.getStorage('access_token');
            request = request.clone({
                setHeaders: { Authorization: `Bearer ${accessToken}` }
            });
        }

        return next.handle(request).pipe(
            catchError((error) => {
                if (error instanceof HttpErrorResponse) {
                    console.log("error in interceptor - ", error);
                    this.toastService.showToast(error.statusText, 'danger');
                }
                return throwError(error);
            }),
            map((response: HttpEvent<any>) => {
                if (response instanceof HttpResponse) {

                }
                return response; // Return the response or modified response
            })
        )
    }


}

