import { Injectable } from '@angular/core';

import {
    CanActivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';

import { MatDialog } from '@angular/material/dialog';

import { Observable } from 'rxjs';

import { AuthenticationService } from '@ECommerce/service/authentication.service';
import { SignInComponent } from '@ECommerce/component/sign-in/sign-in.component';

@Injectable({
    providedIn: 'root'
})

export class AuthGuard implements CanActivate {
    constructor(
        private dialog: MatDialog,
        private authenticationService: AuthenticationService
    ) {
    }

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

        if (this.authenticationService.isSignIn()) {
            return true;
        } else {

            const dialogRef = this.dialog.open(SignInComponent, {
                width: '650px',
                panelClass: 'mat_dialog_container_override',
            });
        }
        return false;
    }
}
