import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutOneComponent } from './layout/layout-one/layout-one.component';
import { LayoutTwoComponent } from './layout/layout-two/layout-two.component';

import { AuthGuard } from './guard/auth.guard';

const routes: Routes = [
    {
        path: '',
        redirectTo: 'product/list',
        pathMatch: 'full'
    },
    {
        path: '',
        component: LayoutTwoComponent,
        children: [
            {
                path: 'sign-up',
                loadChildren: () => import('./component/sign-up/sign-up.module').then(m => m.SignUpModule)
            }
        ]
    },
    {
        path: '',
        component: LayoutOneComponent,
        children: [
            {
                path: 'sign-up',
                loadChildren: () => import('./component/sign-up/sign-up.module').then(m => m.SignUpModule)
            },
            {
                path: 'product',
                loadChildren: () => import('./component/product/product.module').then(m => m.ProductModule)
            },
            {
                path: 'shopping-cart',
                loadChildren: () => import('./component/shopping-cart/shopping-cart.module').then(m => m.ShoppingCartModule),
                canActivate: [AuthGuard]
            }
        ]
    },
    {
        path: '**',
        redirectTo: 'product/list',
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }