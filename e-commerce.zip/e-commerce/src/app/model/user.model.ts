export interface UserI {
    id: number;
    email: string;
    password: string;
    name: string;
    role: string;
    avatar: string;
}

export class User implements UserI {
    id: number = 0;
    email: string = '';
    password: string = '';
    name: string = '';
    role: string = '';
    avatar: string = '';
}