export interface CategoryI {
    id: number;
    name: string;
    image: string;
}

export class Category implements CategoryI {
    id: number = 0;
    name: string = '';
    image: string = '';
}