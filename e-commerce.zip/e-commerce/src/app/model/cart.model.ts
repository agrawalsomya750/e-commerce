export interface CartI {
    id: number;
    title: string;
    description: string;
    price: number;
    image: string;
    quantity: number;
}