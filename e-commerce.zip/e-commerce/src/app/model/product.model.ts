export interface ProductI {
    id: number;
    title: string;
    price: number;
    description: string;
    images: string[];
    creationAt: string;
    updatedAt: string;
    category: {
        id: number;
        name: string;
        image: string;
        creationAt: string;
        updatedAt: string;
    };
}

export class Product implements ProductI {
    id: number = 0;
    title: string = '';
    price: number = 0;
    description: string = '';
    images: string[] = [];
    creationAt: string = '';
    updatedAt: string = '';
    category: {
        id: number;
        name: string;
        image: string;
        creationAt: string;
        updatedAt: string;
    } = {
            id: 0,
            name: '',
            image: '',
            creationAt: '',
            updatedAt: ''
        };
}