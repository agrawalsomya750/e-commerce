export const VALIDATION_CONSTANT = {

    USER_NAME_VALIDATION: {
        maxLength: 50,
        minLength: 2,
        pattern: "^[a-zA-Z]+(?:[ '-_][a-zA-Z]+)*$",
        description: "Valid characters: alphabets, hyphens, underscores, apostrophes, and spaces (no leading or trailing spaces)."
    }

}