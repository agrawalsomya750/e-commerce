import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { LayoutOneComponent } from './layout-one.component';

import { HeaderModule } from '@ECommerce/header/header.module';
import { LoaderModule } from '@ECommerce/loader/loader.module';

@NgModule({
    declarations: [
        LayoutOneComponent
    ],
    imports: [
        CommonModule,
        RouterModule,

        HeaderModule,
        LoaderModule
    ],
    exports: [
        LayoutOneComponent
    ]
})
export class LayoutOneModule { }
