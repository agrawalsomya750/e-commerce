import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { LayoutTwoComponent } from './layout-two.component';

import { HeaderModule } from '@ECommerce/header/header.module';
import { LoaderModule } from '@ECommerce/loader/loader.module';

@NgModule({
    declarations: [
        LayoutTwoComponent
    ],
    imports: [
        CommonModule,
        RouterModule,

        HeaderModule,
        LoaderModule
    ],
    exports: [
        LayoutTwoComponent
    ]
})
export class LayoutTwoModule { }
