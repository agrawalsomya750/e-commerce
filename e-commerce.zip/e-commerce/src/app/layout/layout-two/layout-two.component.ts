import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-layout-two',
    templateUrl: './layout-two.component.html',
    styleUrls: ['./layout-two.component.scss']
})

export class LayoutTwoComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }

}